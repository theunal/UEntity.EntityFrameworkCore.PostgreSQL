﻿namespace TestSetupDbContext
{
    public class DbContext
    {
    }
}